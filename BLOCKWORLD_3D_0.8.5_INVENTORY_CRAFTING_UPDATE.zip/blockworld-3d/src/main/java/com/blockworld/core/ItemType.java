package com.blockworld.core;

/** Crafted item IDs are stable because player sidecar files store these names. */
public enum ItemType {
    PLANKS("planks", "Доски"),
    STICKS("sticks", "Палки"),
    CRAFTING_TABLE("crafting_table", "Верстак"),
    TORCH("torch", "Факел");

    private final String id;
    private final String displayName;

    ItemType(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }

    public static ItemType fromId(String id) {
        for (ItemType type : values()) if (type.id.equalsIgnoreCase(id)) return type;
        throw new IllegalArgumentException("Неизвестный предмет: " + id);
    }
}
