package com.blockworld.core;

import java.util.Map;

/** Small deterministic recipe registry for the first survival crafting release. */
public record CraftingRecipe(int number, String name, Map<BlockType, Integer> blockCosts,
                             Map<ItemType, Integer> itemCosts, ItemType result, int resultCount) {
    public CraftingRecipe {
        if (number < 1 || resultCount < 1) throw new IllegalArgumentException("Некорректный рецепт");
        blockCosts = Map.copyOf(blockCosts);
        itemCosts = Map.copyOf(itemCosts);
    }

    public static java.util.List<CraftingRecipe> starterRecipes() {
        return java.util.List.of(
                new CraftingRecipe(1, "Доски", Map.of(BlockType.WOOD, 2), Map.of(), ItemType.PLANKS, 4),
                new CraftingRecipe(2, "Палки", Map.of(), Map.of(ItemType.PLANKS, 2), ItemType.STICKS, 4),
                new CraftingRecipe(3, "Верстак", Map.of(), Map.of(ItemType.PLANKS, 4), ItemType.CRAFTING_TABLE, 1),
                new CraftingRecipe(4, "Факелы", Map.of(BlockType.COAL_ORE, 1), Map.of(ItemType.STICKS, 2), ItemType.TORCH, 4)
        );
    }

    public boolean canCraft(Map<BlockType, Integer> blocks, Map<ItemType, Integer> items) {
        return blockCosts.entrySet().stream().allMatch(e -> blocks.getOrDefault(e.getKey(), 0) >= e.getValue())
                && itemCosts.entrySet().stream().allMatch(e -> items.getOrDefault(e.getKey(), 0) >= e.getValue());
    }

    public boolean craft(Map<BlockType, Integer> blocks, Map<ItemType, Integer> items) {
        if (!canCraft(blocks, items)) return false;
        blockCosts.forEach((type, count) -> blocks.put(type, blocks.get(type) - count));
        itemCosts.forEach((type, count) -> items.put(type, items.get(type) - count));
        items.merge(result, resultCount, Integer::sum);
        return true;
    }

    public String ingredientsText() {
        java.util.List<String> parts = new java.util.ArrayList<>();
        blockCosts.forEach((type, count) -> parts.add(type.displayName() + " × " + count));
        itemCosts.forEach((type, count) -> parts.add(type.displayName() + " × " + count));
        return parts.isEmpty() ? "без ингредиентов" : String.join(" + ", parts);
    }
}
