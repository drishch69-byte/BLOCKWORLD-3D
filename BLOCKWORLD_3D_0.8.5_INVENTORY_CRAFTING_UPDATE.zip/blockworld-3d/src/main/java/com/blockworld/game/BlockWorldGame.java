package com.blockworld.game;

import com.blockworld.core.BlockHit;
import com.blockworld.core.BlockPos;
import com.blockworld.core.BlockType;
import com.blockworld.core.ItemType;
import com.blockworld.core.CraftingRecipe;
import com.blockworld.core.PlayerDataStore;
import com.blockworld.core.GameVersion;
import com.blockworld.core.GameSettings;
import com.blockworld.core.GamePaths;
import com.blockworld.core.ResourcePackManager;
import com.blockworld.core.ModLoader;
import com.blockworld.api.ModContext;
import com.blockworld.core.GameLog;
import com.blockworld.core.VoxelWorld;
import com.jme3.app.SimpleApplication;
import com.jme3.collision.CollisionResult;
import com.jme3.collision.CollisionResults;
import com.jme3.font.BitmapText;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.AnalogListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseAxisTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.math.ColorRGBA;
import com.jme3.math.FastMath;
import com.jme3.math.Quaternion;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Quad;
import com.jme3.system.AppSettings;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/** Main 3D game window and input handling. */
public final class BlockWorldGame extends SimpleApplication {
    private static final String BREAK = "breakBlock";
    private static final String PLACE = "placeBlock";
    private static final String SAVE = "saveWorld";
    private static final String EAT = "eatFood";
    private static final String TALK = "interactCreature";

    private final GameVersion version;
    private final Path saveFile;
    private final boolean createNewWorld;
    private final Runnable onGameExit;
    private final GameSettings gameSettings;
    private final Map<BlockType, Integer> inventory = new EnumMap<>(BlockType.class);
    private final Map<ItemType, Integer> craftedItems = new EnumMap<>(ItemType.class);
    private final List<CraftingRecipe> craftingRecipes = CraftingRecipe.starterRecipes();

    private VoxelWorld world;
    private ModLoader modLoader;
    private CreatureManager creatureManager;
    private boolean modsWorldReady;
    private int loadedModCount;
    private BitmapText hud;
    private BitmapText crosshair;
    private Geometry hudPanel;
    private Geometry loadingPad;
    private Geometry pausePanel;
    private BitmapText pauseText;
    private Geometry inventoryPanel;
    private BitmapText inventoryText;
    private boolean inventoryOpen;
    private boolean craftingOpen;
    private boolean paused;
    private List<BlockType> hotbar;
    private BlockType selectedBlock = BlockType.GRASS;
    private volatile String statusMessage = "Добро пожаловать в BlockWorld!";
    private boolean exitNotified;
    private volatile boolean runtimeFault;
    private volatile String runtimeFaultMessage = "";
    private volatile boolean worldDataReady;
    private volatile String loadingMessage = "Подготовка мира...";
    private boolean worldReady;
    private boolean worldNodeAttached;
    private Vector3f spawnPosition = new Vector3f(0f, 4.68f, 8f);
    private float fpsEstimate = 60f;
    private int renderDistanceIndex = 0;
    private boolean twoSidedRendering = true;
    private DirectionalLight natureSun;
    private float dayClock = 0f;
    private boolean raining = false;
    private static final int[] RENDER_DISTANCES = {3, 4, 6, 8};

    // Survival state.
    private boolean moveForward;
    private boolean moveBackward;
    private boolean moveLeft;
    private boolean moveRight;
    private boolean jumpRequested;
    private boolean onGround;
    private float verticalVelocity;
    private float yaw;
    private float pitch = -0.42f;
    private float health = 20f;
    private float hunger = 20f;
    private int foodCount = 3;
    private float hungerClock;
    private float starvationClock;
    private float hudRefreshClock;
    private float chunkWaitClock;

    public BlockWorldGame(GameVersion version, Path saveFile, boolean createNewWorld, Runnable onGameExit) {
        this(version, saveFile, createNewWorld, onGameExit, GameSettings.load());
    }

    public BlockWorldGame(GameVersion version, Path saveFile, boolean createNewWorld,
                          Runnable onGameExit, GameSettings gameSettings) {
        this.version = version;
        this.saveFile = saveFile;
        this.createNewWorld = createNewWorld;
        this.onGameExit = onGameExit;
        this.gameSettings = gameSettings == null ? GameSettings.DEFAULT : gameSettings;
    }

    public void launch() {
        AppSettings settings = new AppSettings(true);
        settings.setTitle("BLOCKWORLD 3D  |  " + version.id() + " " + version.displayName());
        settings.setResolution(gameSettings.width(), gameSettings.height());
        settings.setFullscreen(gameSettings.fullscreen());
        settings.setResizable(true);
        settings.setVSync(gameSettings.vsync());
        settings.setSamples(0);
        setSettings(settings);
        setShowSettings(false);
        GameLog.info("Запуск окна игры: " + version.id() + "; resolution=" + gameSettings.width() + "x" + gameSettings.height()
                + "; samples=0; vsync=" + gameSettings.vsync() + "; fullscreen=" + gameSettings.fullscreen() + "; resizable=true"
                + "; Java=" + System.getProperty("java.version")
                + "; OS=" + System.getProperty("os.name") + " " + System.getProperty("os.arch")
                + "; thread=" + Thread.currentThread().getName());
        GameLog.info("Передан вызов SimpleApplication.start().");
        start();
        GameLog.info("SimpleApplication.start() завершился без выброшенного исключения.");
    }

    @Override
    public void simpleInitApp() {
        GameLog.info("jMonkeyEngine вызвал simpleInitApp(); контекст и рендер-поток созданы.");
        setDisplayFps(false);
        setDisplayStatView(false);
        // A wider FOV and a short near plane keep nearby terrain visible in first-person view.
        cam.setFrustumPerspective(gameSettings.fov(), (float) settings.getWidth() / settings.getHeight(), 0.1f, 900f);
        viewPort.setBackgroundColor(new ColorRGBA(0.48f, 0.72f, 0.94f, 1f));

        flyCam.setMoveSpeed(11f);
        natureSun = new DirectionalLight();
        natureSun.setDirection(new Vector3f(-0.45f, -1f, -0.35f).normalizeLocal());
        natureSun.setColor(ColorRGBA.White.mult(1.15f));
        rootNode.addLight(natureSun);
        AmbientLight ambient = new AmbientLight();
        ambient.setColor(new ColorRGBA(0.62f, 0.66f, 0.72f, 1f));
        rootNode.addLight(ambient);

        java.util.Map<BlockType, ColorRGBA> palette = java.util.Map.of();
        com.jme3.texture.Texture2D textureAtlas = null;
        try {
            ResourcePackManager packs = new ResourcePackManager();
            palette = packs.loadPalette();
            textureAtlas = packs.loadTextureAtlas();
            GameLog.info("Применён ресурс-пак «" + packs.selectedPackId() + "» с PNG-текстурным атласом.");
        } catch (IOException | RuntimeException ex) {
            GameLog.error("Не удалось загрузить текстуры ресурс-пака; используется цветовой режим", ex);
        }
        world = new VoxelWorld(assetManager, palette, textureAtlas);
        creatureManager = new CreatureManager(assetManager);
        GameLog.info("Сцена создана; материал чанков, существа и AssetManager инициализированы. Цветов ресурс-пака: " + palette.size()
                + "; текстурный атлас: " + (textureAtlas != null));
        int savedDistance = gameSettings.renderDistance();
        for (int i = 0; i < RENDER_DISTANCES.length; i++) if (RENDER_DISTANCES[i] == savedDistance) renderDistanceIndex = i;
        world.setRenderDistanceChunks(RENDER_DISTANCES[renderDistanceIndex]);
        modLoader = new ModLoader(GamePaths.modsDirectory());
        loadedModCount = modLoader.load(new ModContext(world, version, GamePaths.configDirectory()));
        GameLog.info("Активных модов: " + loadedModCount);
        world.setTwoSidedRendering(twoSidedRendering);

        hotbar = switch (version.id()) {
            case "0.1.0" -> List.of(BlockType.GRASS, BlockType.DIRT, BlockType.STONE);
            case "0.2.0" -> List.of(BlockType.GRASS, BlockType.DIRT, BlockType.STONE,
                    BlockType.WOOD, BlockType.SAND);
            default -> List.of(BlockType.GRASS, BlockType.DIRT, BlockType.STONE,
                    BlockType.WOOD, BlockType.LEAVES, BlockType.SAND,
                    BlockType.COAL_ORE, BlockType.IRON_ORE, BlockType.GOLD_ORE);
        };

        if (version.survival()) {
            for (BlockType type : BlockType.values()) inventory.put(type, 0);
            inventory.put(BlockType.GRASS, 16);
            inventory.put(BlockType.DIRT, 16);
            inventory.put(BlockType.STONE, 16);
            inventory.put(BlockType.WOOD, 4);
            inventory.put(BlockType.COAL_ORE, 2);
            for (ItemType item : ItemType.values()) craftedItems.put(item, 0);
            flyCam.setEnabled(false);
            inputManager.setCursorVisible(false);
            cam.setLocation(new Vector3f(0f, 12f, 8f));
            cam.setRotation(new Quaternion().fromAngles(pitch, yaw, 0f));
        } else {
            cam.setLocation(new Vector3f(0f, 16f, 26f));
            cam.lookAt(new Vector3f(0f, 1f, 0f), Vector3f.UNIT_Y);
        }

        setupHud();
        setupInputs();
        GameLog.info("HUD и управление инициализированы; запускается подготовка данных мира.");
        statusMessage = "Мир подготавливается в фоновом потоке...";
        updateHud();
        GameLog.info("Запуск профиля " + version.id() + "; сохранение: " + saveFile.toAbsolutePath());
        // Data generation/loading does not block the render thread. Chunks are meshed gradually below.
        CompletableFuture.runAsync(this::prepareWorldData).whenComplete((ignored, error) -> {
            if (error != null) {
                Throwable cause = error instanceof java.util.concurrent.CompletionException && error.getCause() != null
                        ? error.getCause() : error;
                GameLog.error("Фоновая генерация мира завершилась аварийно", cause);
                statusMessage = "Сбой генерации мира: " + cause.getClass().getSimpleName()
                        + " — " + (cause.getMessage() == null ? "без описания" : cause.getMessage());
                loadingMessage = "Ошибка подготовки мира. См. журнал.";
                worldDataReady = true;
            } else {
                GameLog.info("Фоновая подготовка мира завершена без исключения.");
            }
        });
    }

    private void prepareWorldData() {
        boolean loaded = false;
        try {
            if (!createNewWorld && Files.exists(saveFile)) {
                try {
                    String savedWith = world.load(saveFile);
                    statusMessage = "Загружен мир. Последнее сохранение: " + savedWith + ".";
                    loaded = true;
                    if (!savedWith.equals(version.id())) statusMessage += " Открыт в версии " + version.id() + ".";
                    if (world.getBlockCount() == 0) {
                        statusMessage = "Сохранение пустое. Создаю новый мир вместо пустой сцены.";
                        loaded = false;
                    }
                } catch (IOException ex) {
                    statusMessage = "Не удалось загрузить мир: " + ex.getMessage();
                    try {
                        Path backup = saveFile.resolveSibling(saveFile.getFileName() + ".load-error-backup");
                        Files.copy(saveFile, backup, StandardCopyOption.REPLACE_EXISTING);
                        statusMessage += " Резервная копия: " + backup.getFileName() + ".";
                    } catch (IOException backupError) {
                        statusMessage += " Не удалось создать резервную копию файла.";
                    }
                }
            }

            if (loaded && version.survival()) {
                try { PlayerDataStore.load(saveFile, inventory, craftedItems); }
                catch (IOException ex) { GameLog.error("Не удалось загрузить инвентарь игрока; используются стартовые значения", ex); }
            }
            if (!loaded) {
                long newSeed = ThreadLocalRandom.current().nextLong();
                world.generate(version, newSeed);
                try {
                    world.save(saveFile, version);
                    if (version.survival()) PlayerDataStore.save(saveFile, inventory, craftedItems);
                    statusMessage += " Новый мир создан. Seed: " + newSeed + ".";
                } catch (IOException ex) {
                    statusMessage += " Мир создан, но не сохранён: " + ex.getMessage();
                }
            }
            loadingMessage = "Подготовка чанков...";
            GameLog.info("Данные мира готовы: блоков=" + world.getBlockCount()
                    + ", чанков=" + world.getChunkCount() + ", seed=" + world.getSeed());
        } catch (RuntimeException ex) {
            statusMessage = "Ошибка подготовки мира: " + ex.getMessage();
            loadingMessage = "Не удалось подготовить мир";
            GameLog.error("Ошибка подготовки данных мира", ex);
        } finally {
            worldDataReady = true;
        }
    }

    private void setupHud() {
        guiNode.detachAllChildren();
        guiFont = assetManager.loadFont("Interface/Fonts/Default.fnt");

        Material panelMaterial = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        panelMaterial.setColor("Color", new ColorRGBA(0.025f, 0.04f, 0.065f, 0.84f));
        panelMaterial.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        panelMaterial.getAdditionalRenderState().setDepthWrite(false);
        hudPanel = new Geometry("HUD-Background", new Quad(900f, 174f));
        hudPanel.setMaterial(panelMaterial);
        hudPanel.setQueueBucket(RenderQueue.Bucket.Gui);
        hudPanel.setLocalTranslation(7f, settings.getHeight() - 181f, 1f);
        guiNode.attachChild(hudPanel);

        hud = new BitmapText(guiFont);
        hud.setSize(15f);
        hud.setColor(ColorRGBA.White);
        hud.setQueueBucket(RenderQueue.Bucket.Gui);
        hud.setLocalTranslation(15f, settings.getHeight() - 14f, 0f);
        guiNode.attachChild(hud);

        crosshair = new BitmapText(guiFont);
        crosshair.setText("+");
        crosshair.setSize(24f);
        crosshair.setColor(ColorRGBA.White);
        crosshair.setLocalTranslation(settings.getWidth() / 2f - 5f, settings.getHeight() / 2f + 7f, 0f);
        guiNode.attachChild(crosshair);

        Material pauseMaterial = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        pauseMaterial.setColor("Color", new ColorRGBA(0.015f, 0.025f, 0.045f, 0.94f));
        pauseMaterial.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        pauseMaterial.getAdditionalRenderState().setDepthWrite(false);
        pausePanel = new Geometry("PauseMenuPanel", new Quad(520f, 250f));
        pausePanel.setMaterial(pauseMaterial);
        pausePanel.setQueueBucket(RenderQueue.Bucket.Gui);
        pausePanel.setLocalTranslation(settings.getWidth() / 2f - 260f, settings.getHeight() / 2f - 125f, 4f);
        pauseText = new BitmapText(guiFont);
        pauseText.setSize(22f);
        pauseText.setColor(ColorRGBA.White);
        pauseText.setQueueBucket(RenderQueue.Bucket.Gui);
        pauseText.setText("BLOCKWORLD 3D — ПАУЗА\n\nESC — продолжить игру\nF6 — сохранить мир\nF10 — выйти в главное меню");
        pauseText.setLocalTranslation(settings.getWidth() / 2f - 205f, settings.getHeight() / 2f + 82f, 5f);

        Material inventoryMaterial = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        inventoryMaterial.setColor("Color", new ColorRGBA(0.025f, 0.04f, 0.065f, 0.96f));
        inventoryMaterial.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        inventoryMaterial.getAdditionalRenderState().setDepthWrite(false);
        inventoryPanel = new Geometry("InventoryCraftingPanel", new Quad(570f, 390f));
        inventoryPanel.setMaterial(inventoryMaterial);
        inventoryPanel.setQueueBucket(RenderQueue.Bucket.Gui);
        inventoryPanel.setLocalTranslation(settings.getWidth() / 2f - 285f, settings.getHeight() / 2f - 195f, 8f);
        inventoryText = new BitmapText(guiFont);
        inventoryText.setSize(17f);
        inventoryText.setColor(ColorRGBA.White);
        inventoryText.setQueueBucket(RenderQueue.Bucket.Gui);
        inventoryText.setLocalTranslation(settings.getWidth() / 2f - 260f, settings.getHeight() / 2f + 165f, 9f);
        updateInventoryUi();
    }

    private void setupInputs() {
        inputManager.addMapping(BREAK, new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
        inputManager.addMapping(PLACE, new MouseButtonTrigger(MouseInput.BUTTON_RIGHT));
        inputManager.addMapping(SAVE, new KeyTrigger(KeyInput.KEY_F6));
        inputManager.addMapping("SLOT_1", new KeyTrigger(KeyInput.KEY_1));
        inputManager.addMapping("SLOT_2", new KeyTrigger(KeyInput.KEY_2));
        inputManager.addMapping("SLOT_3", new KeyTrigger(KeyInput.KEY_3));
        inputManager.addMapping("SLOT_4", new KeyTrigger(KeyInput.KEY_4));
        inputManager.addMapping("SLOT_5", new KeyTrigger(KeyInput.KEY_5));
        inputManager.addMapping("SLOT_6", new KeyTrigger(KeyInput.KEY_6));
        inputManager.addMapping("SLOT_7", new KeyTrigger(KeyInput.KEY_7));
        inputManager.addMapping("SLOT_8", new KeyTrigger(KeyInput.KEY_8));
        inputManager.addMapping("SLOT_9", new KeyTrigger(KeyInput.KEY_9));
        inputManager.addMapping("TOGGLE_PAUSE", new KeyTrigger(KeyInput.KEY_ESCAPE));
        inputManager.addMapping("EXIT_GAME", new KeyTrigger(KeyInput.KEY_F10));
        inputManager.addMapping(EAT, new KeyTrigger(KeyInput.KEY_E));
        inputManager.addMapping(TALK, new KeyTrigger(KeyInput.KEY_F));
        inputManager.addMapping("RENDER_DISTANCE", new KeyTrigger(KeyInput.KEY_F7));
        inputManager.addMapping("TOGGLE_CULLING", new KeyTrigger(KeyInput.KEY_F8));
        inputManager.addMapping("WEATHER", new KeyTrigger(KeyInput.KEY_R));
        inputManager.addMapping("TOGGLE_INVENTORY", new KeyTrigger(KeyInput.KEY_I));
        inputManager.addMapping("TOGGLE_CRAFTING", new KeyTrigger(KeyInput.KEY_C));

        if (version.survival()) {
            inputManager.addMapping("MOVE_FORWARD", new KeyTrigger(KeyInput.KEY_W));
            inputManager.addMapping("MOVE_BACK", new KeyTrigger(KeyInput.KEY_S));
            inputManager.addMapping("MOVE_LEFT", new KeyTrigger(KeyInput.KEY_A));
            inputManager.addMapping("MOVE_RIGHT", new KeyTrigger(KeyInput.KEY_D));
            inputManager.addMapping("JUMP", new KeyTrigger(KeyInput.KEY_SPACE));
            inputManager.addMapping("LOOK_RIGHT", new MouseAxisTrigger(MouseInput.AXIS_X, true));
            inputManager.addMapping("LOOK_LEFT", new MouseAxisTrigger(MouseInput.AXIS_X, false));
            inputManager.addMapping("LOOK_UP", new MouseAxisTrigger(MouseInput.AXIS_Y, true));
            inputManager.addMapping("LOOK_DOWN", new MouseAxisTrigger(MouseInput.AXIS_Y, false));

            ActionListener movementListener = (name, pressed, tpf) -> {
                if (paused) return;
                switch (name) {
                    case "MOVE_FORWARD" -> moveForward = pressed;
                    case "MOVE_BACK" -> moveBackward = pressed;
                    case "MOVE_LEFT" -> moveLeft = pressed;
                    case "MOVE_RIGHT" -> moveRight = pressed;
                    case "JUMP" -> {
                        if (pressed && onGround) {
                            verticalVelocity = 7f;
                            onGround = false;
                        }
                    }
                    default -> { }
                }
            };
            inputManager.addListener(movementListener,
                    "MOVE_FORWARD", "MOVE_BACK", "MOVE_LEFT", "MOVE_RIGHT", "JUMP");
            AnalogListener lookListener = (name, value, tpf) -> {
                if (paused) return;
                float sensitivity = 2.2f;
                switch (name) {
                    case "LOOK_LEFT" -> yaw += value * sensitivity;
                    case "LOOK_RIGHT" -> yaw -= value * sensitivity;
                    case "LOOK_UP" -> pitch += value * sensitivity;
                    case "LOOK_DOWN" -> pitch -= value * sensitivity;
                    default -> { }
                }
                pitch = Math.max(-1.45f, Math.min(1.45f, pitch));
                cam.setRotation(new Quaternion().fromAngles(pitch, yaw, 0f));
            };
            inputManager.addListener(lookListener, "LOOK_LEFT", "LOOK_RIGHT", "LOOK_UP", "LOOK_DOWN");
        }

        ActionListener actions = (name, isPressed, tpf) -> {
            if (!isPressed) {
                return;
            }
            if (paused && !name.equals("TOGGLE_PAUSE") && !name.equals("SAVE") && !name.equals("EXIT_GAME")) return;
            switch (name) {
                case BREAK -> breakTargetBlock();
                case PLACE -> placeTargetBlock();
                case SAVE -> saveWorld();
                case EAT -> eatFood();
                case TALK -> interactCreature();
                case "RENDER_DISTANCE" -> cycleRenderDistance();
                case "TOGGLE_CULLING" -> toggleCulling();
                case "WEATHER" -> toggleWeather();
                case "TOGGLE_INVENTORY" -> toggleInventory();
                case "TOGGLE_CRAFTING" -> toggleCrafting();
                case "TOGGLE_PAUSE" -> setPaused(!paused);
                case "EXIT_GAME" -> {
                    if (paused) stop();
                    else { statusMessage = "Нажми ESC, чтобы открыть меню паузы, затем F10 для выхода."; updateHud(); }
                }
                case "SLOT_1" -> { if (craftingOpen && 1 <= craftingRecipes.size()) craftRecipe(0); else if (!craftingOpen) selectSlot(0); }
                case "SLOT_2" -> { if (craftingOpen && 2 <= craftingRecipes.size()) craftRecipe(1); else if (!craftingOpen) selectSlot(1); }
                case "SLOT_3" -> { if (craftingOpen && 3 <= craftingRecipes.size()) craftRecipe(2); else if (!craftingOpen) selectSlot(2); }
                case "SLOT_4" -> { if (craftingOpen && 4 <= craftingRecipes.size()) craftRecipe(3); else if (!craftingOpen) selectSlot(3); }
                case "SLOT_5" -> { if (craftingOpen && 5 <= craftingRecipes.size()) craftRecipe(4); else if (!craftingOpen) selectSlot(4); }
                case "SLOT_6" -> { if (craftingOpen && 6 <= craftingRecipes.size()) craftRecipe(5); else if (!craftingOpen) selectSlot(5); }
                case "SLOT_7" -> { if (craftingOpen && 7 <= craftingRecipes.size()) craftRecipe(6); else if (!craftingOpen) selectSlot(6); }
                case "SLOT_8" -> { if (craftingOpen && 8 <= craftingRecipes.size()) craftRecipe(7); else if (!craftingOpen) selectSlot(7); }
                case "SLOT_9" -> { if (craftingOpen && 9 <= craftingRecipes.size()) craftRecipe(8); else if (!craftingOpen) selectSlot(8); }
                default -> { }
            }
        };
        inputManager.addListener(actions, BREAK, PLACE, SAVE, EAT, "EXIT_GAME", "TOGGLE_PAUSE",
                "SLOT_1", "SLOT_2", "SLOT_3", "SLOT_4", "SLOT_5",
                "SLOT_6", "SLOT_7", "SLOT_8", "SLOT_9", "RENDER_DISTANCE", "TOGGLE_CULLING", "WEATHER", TALK,
                "TOGGLE_INVENTORY", "TOGGLE_CRAFTING");
    }

    @Override
    public void simpleUpdate(float tpf) {
        if (paused) return;
        if (runtimeFault) {
            hudRefreshClock += Math.max(0f, tpf);
            if (hudRefreshClock >= 0.5f) {
                hudRefreshClock = 0f;
                updateHud();
            }
            return;
        }
        try {
            updateFrame(tpf);
        } catch (RuntimeException error) {
            runtimeFault = true;
            runtimeFaultMessage = error.getClass().getSimpleName() + ": "
                    + (error.getMessage() == null ? "без описания" : error.getMessage());
            statusMessage = "Игровой цикл остановлен из-за ошибки: " + runtimeFaultMessage;
            loadingMessage = "Аварийная остановка кадра. См. .logs\\latest-run.log";
            GameLog.error("Необработанная ошибка игрового кадра; окно оставлено открытым для диагностики", error);
            updateHud();
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null,
                    "Игровой цикл встретил ошибку и приостановлен, чтобы окно не исчезло.\n"
                            + runtimeFaultMessage + "\n\nЖурнал: .logs\\latest-run.log",
                    "BLOCKWORLD 3D — ошибка игрового цикла", JOptionPane.ERROR_MESSAGE));
        }
    }

    private void updateFrame(float tpf) {
        if (tpf > 0f) fpsEstimate = fpsEstimate * 0.88f + (1f / tpf) * 0.12f;
        if (version.id().compareTo("0.6.0") >= 0) updateNature(tpf);

        if (worldDataReady) {
            if (!modsWorldReady && modLoader != null) {
                modLoader.worldReady();
                modsWorldReady = true;
            }
            if (!worldNodeAttached) {
                rootNode.attachChild(world.getNode());
                creatureManager.sync(world);
                rootNode.attachChild(creatureManager.getNode());
                GameLog.info("Существа присоединены к сцене: " + creatureManager.size());
                worldNodeAttached = true;
                spawnPosition = world.getSuggestedSpawn();
                createLoadingPad();
                GameLog.info("Точка появления: " + spawnPosition + "; чанк="
                        + com.blockworld.core.ChunkPos.fromBlock(Math.round(spawnPosition.x), Math.round(spawnPosition.z)));
                if (version.survival()) {
                    cam.setLocation(spawnPosition.clone());
                    cam.setRotation(new Quaternion().fromAngles(pitch, yaw, 0f));
                } else {
                    cam.setLocation(spawnPosition.add(0f, 16f, 26f));
                    cam.lookAt(spawnPosition, Vector3f.UNIT_Y);
                }
            }
            // Build only a few chunk meshes per frame to avoid long freezes on modest PCs.
            try {
                world.updateStreaming(cam.getLocation(), worldReady ? 2 : 5);
            } catch (RuntimeException ex) {
                statusMessage = "Ошибка меша чанка: " + ex.getClass().getSimpleName()
                        + " — " + (ex.getMessage() == null ? "без описания" : ex.getMessage());
                loadingMessage = "Ошибка отрисовки. См. .logs\\latest-run.log";
                GameLog.error("Не удалось построить чанк мира", ex);
                updateHud();
            }
            if (!worldReady && world.isChunkRenderedAt(spawnPosition.x, spawnPosition.z)) {
                if (version.survival()) {
                    cam.setLocation(spawnPosition.clone());
                    cam.setRotation(new Quaternion().fromAngles(pitch, yaw, 0f));
                    onGround = true;
                    verticalVelocity = 0f;
                }
                worldReady = true;
                loadingMessage = "Мир загружен";
                if (loadingPad != null) { loadingPad.removeFromParent(); loadingPad = null; }
                statusMessage = "Чанк появления отрисован. Управление готово.";
                GameLog.info("Мир готов: мешей=" + world.getRenderedChunkCount()
                        + ", чанков данных=" + world.getChunkCount());
                updateHud();
            } else if (!worldReady) {
                chunkWaitClock += tpf;
                if (chunkWaitClock >= 5f) {
                    chunkWaitClock = 0f;
                    statusMessage = "Старт: " + Math.round(spawnPosition.x) + ", "
                            + Math.round(spawnPosition.y) + ", " + Math.round(spawnPosition.z)
                            + "; блоков " + world.getBlockCount()
                            + "; чанков данных " + world.getChunkCount()
                            + "; мешей " + world.getRenderedChunkCount()
                            + "; очередь " + world.getPendingChunkCount()
                            + "; меш появления=" + world.isChunkRenderedAt(spawnPosition.x, spawnPosition.z)
                            + (world.getLastMeshError().isBlank() ? "." : "; ошибка: " + world.getLastMeshError());
                    updateHud();
                }
            }
        }

        if (worldReady && modLoader != null) modLoader.update(tpf);
        if (worldReady && creatureManager != null && world != null) {
            creatureManager.update(tpf, cam.getLocation(), world);
        }

        if (worldReady && version.survival() && world != null) {
            updateSurvivalMovement(tpf);
            updateSurvivalNeeds(tpf);
        }

        hudRefreshClock += tpf;
        if (hudRefreshClock >= 0.25f) {
            hudRefreshClock = 0f;
            updateHud();
        }
    }

    private void setPaused(boolean value) {
        if (paused == value || guiNode == null) return;
        paused = value;
        if (paused) {
            inventoryOpen = false;
            craftingOpen = false;
            showInventoryOverlay(false);
            moveForward = moveBackward = moveLeft = moveRight = false;
            if (flyCam != null) flyCam.setEnabled(false);
            inputManager.setCursorVisible(true);
            if (pausePanel.getParent() == null) guiNode.attachChild(pausePanel);
            if (pauseText.getParent() == null) guiNode.attachChild(pauseText);
            statusMessage = "Игра на паузе.";
        } else {
            guiNode.detachChild(pausePanel);
            guiNode.detachChild(pauseText);
            inputManager.setCursorVisible(false);
            if (!version.survival() && flyCam != null) flyCam.setEnabled(true);
            statusMessage = "Игра продолжается.";
        }
        updateHud();
    }

    /** A visible temporary platform proves the 3D scene is rendering while chunks load. */
    private void createLoadingPad() {
        if (loadingPad != null) loadingPad.removeFromParent();
        Material material = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        material.setColor("Color", new ColorRGBA(0.08f, 0.72f, 0.92f, 1f));
        material.getAdditionalRenderState().setFaceCullMode(RenderState.FaceCullMode.Off);
        Quad quad = new Quad(12f, 12f);
        loadingPad = new Geometry("WorldLoadingPad", quad);
        loadingPad.setMaterial(material);
        loadingPad.setLocalRotation(new Quaternion().fromAngleAxis(-FastMath.HALF_PI, Vector3f.UNIT_X));
        // Suggested spawn is 0.68 units above the top face of its surface block.
        loadingPad.setLocalTranslation(spawnPosition.x - 6f, spawnPosition.y - 0.62f,
                spawnPosition.z + 6f);
        loadingPad.setQueueBucket(RenderQueue.Bucket.Opaque);
        rootNode.attachChild(loadingPad);
    }

    private void toggleCulling() {
        twoSidedRendering = !twoSidedRendering;
        world.setTwoSidedRendering(twoSidedRendering);
        statusMessage = twoSidedRendering
                ? "Двусторонняя отрисовка граней включена (диагностика)."
                : "Отсечение обратных граней включено (быстрее).";
        updateHud();
    }

    private void updateNature(float tpf) {
        dayClock = (dayClock + tpf / 240f) % 1f;
        float sunHeight = FastMath.sin(dayClock * FastMath.TWO_PI);
        float daylight = FastMath.clamp((sunHeight + 0.12f) / 0.72f, 0.12f, 1f);
        float warmth = raining ? 0.58f : 1f;
        natureSun.setDirection(new Vector3f(FastMath.cos(dayClock * FastMath.TWO_PI),
                -Math.max(0.12f, sunHeight), -0.35f).normalizeLocal());
        natureSun.setColor(new ColorRGBA(daylight * warmth, daylight * warmth, daylight, 1f));
        float sky = raining ? 0.34f : 0.48f * daylight + 0.025f;
        viewPort.setBackgroundColor(new ColorRGBA(sky, sky + (raining ? 0.035f : 0.24f * daylight),
                sky + (raining ? 0.055f : 0.46f * daylight), 1f));
    }

    private void toggleWeather() {
        raining = !raining;
        statusMessage = raining ? "Погода: дождливая. Нажми R, чтобы очистить небо."
                : "Погода: ясно.";
        updateHud();
    }

    private void cycleRenderDistance() {
        renderDistanceIndex = (renderDistanceIndex + 1) % RENDER_DISTANCES.length;
        int distance = RENDER_DISTANCES[renderDistanceIndex];
        world.setRenderDistanceChunks(distance);
        try {
            GameSettings.save(new GameSettings(gameSettings.width(), gameSettings.height(), gameSettings.fullscreen(),
                    gameSettings.vsync(), distance, gameSettings.fov()));
        } catch (IOException ex) { GameLog.error("Не удалось сохранить дальность прорисовки", ex); }
        statusMessage = "Дальность прорисовки: " + distance + " чанков. Для слабого ПК выбери 3.";
        updateHud();
    }

    private void updateSurvivalMovement(float tpf) {
        Vector3f direction = new Vector3f();
        Vector3f forward = cam.getDirection().clone().setY(0f);
        Vector3f left = cam.getLeft().clone().setY(0f);
        if (forward.lengthSquared() > 0f) forward.normalizeLocal();
        if (left.lengthSquared() > 0f) left.normalizeLocal();
        if (moveForward) direction.addLocal(forward);
        if (moveBackward) direction.subtractLocal(forward);
        if (moveLeft) direction.addLocal(left);
        if (moveRight) direction.subtractLocal(left);
        if (direction.lengthSquared() > 0f) {
            direction.normalizeLocal().multLocal(5.2f * tpf);
        }

        Vector3f location = cam.getLocation().clone();
        location.addLocal(direction.x, 0f, direction.z);
        float minWorldX = world.getMinBlockX() + 1.5f;
        float maxWorldX = world.getMaxBlockX() - 1.5f;
        float minWorldZ = world.getMinBlockZ() + 1.5f;
        float maxWorldZ = world.getMaxBlockZ() - 1.5f;
        location.x = Math.max(minWorldX, Math.min(maxWorldX, location.x));
        location.z = Math.max(minWorldZ, Math.min(maxWorldZ, location.z));
        int groundX = Math.round(location.x);
        int groundZ = Math.round(location.z);
        float groundEyeY = world.highestBlockY(groundX, groundZ) + 1.68f;

        verticalVelocity -= 19f * tpf;
        location.y += verticalVelocity * tpf;
        if (location.y <= groundEyeY) {
            location.y = groundEyeY;
            verticalVelocity = 0f;
            onGround = true;
        } else {
            onGround = false;
        }
        cam.setLocation(location);
    }

    private void updateSurvivalNeeds(float tpf) {
        hungerClock += tpf;
        if (hunger > 0f) {
            starvationClock = 0f;
        } else {
            starvationClock += tpf;
        }
        if (hungerClock >= 35f) {
            hungerClock = 0f;
            hunger = Math.max(0f, hunger - 1f);
        }
        if (hunger <= 0f && starvationClock >= 8f) {
            starvationClock = 0f;
            health = Math.max(0f, health - 1f);
        }
        if (health <= 0f) {
            health = 20f;
            hunger = 10f;
            verticalVelocity = 0f;
            spawnPosition = world.getSuggestedSpawn();
            cam.setLocation(spawnPosition.clone());
            statusMessage = "Ты возродился на точке появления. Часть прогресса персонажа пока не сохраняется.";
        }
    }

    private BlockHit getTargetBlock() {
        if (!worldReady) return null;
        CollisionResults results = new CollisionResults();
        Ray ray = new Ray(cam.getLocation(), cam.getDirection());
        ray.setLimit(6f);
        world.getNode().collideWith(ray, results);
        if (results.size() == 0) return null;
        CollisionResult closest = results.getClosestCollision();
        return world.getHitFace(closest.getGeometry(), closest.getTriangleIndex());
    }

    private void breakTargetBlock() {
        if (!worldReady) {
            statusMessage = "Мир ещё загружается.";
            updateHud();
            return;
        }
        BlockHit hit = getTargetBlock();
        if (hit == null) {
            statusMessage = "Рядом нет блока.";
            updateHud();
            return;
        }
        BlockPos pos = hit.position();
        BlockType removed = world.getBlock(pos);
        if (world.removeBlock(pos)) {
            if (version.survival() && removed != null) {
                inventory.merge(removed, 1, Integer::sum);
                statusMessage = "Собрано: " + removed.displayName() + " × " + inventory.get(removed) + ".";
            } else {
                statusMessage = "Блок разрушен.";
            }
            updateHud();
        }
    }

    private void placeTargetBlock() {
        if (!worldReady) {
            statusMessage = "Мир ещё загружается.";
            updateHud();
            return;
        }
        BlockHit hit = getTargetBlock();
        if (hit == null) {
            statusMessage = "Наведи прицел на блок, чтобы поставить рядом новый.";
            updateHud();
            return;
        }
        BlockPos target = hit.adjacentPosition();
        Vector3f targetCenter = new Vector3f(target.x(), target.y(), target.z());
        int available = inventory.getOrDefault(selectedBlock, 0);
        if (cam.getLocation().distance(targetCenter) < 1.45f) {
            statusMessage = "Слишком близко: нельзя поставить блок внутри игрока.";
        } else if (version.survival() && available <= 0) {
            statusMessage = "В инвентаре нет блока «" + selectedBlock.displayName() + "».";
        } else if (world.addBlock(target, selectedBlock)) {
            if (version.survival()) inventory.put(selectedBlock, available - 1);
            statusMessage = "Поставлен блок: " + selectedBlock.displayName() + ".";
        } else {
            statusMessage = "Место занято или достигнут лимит блоков.";
        }
        updateHud();
    }

    private void interactCreature() {
        if (!worldReady || creatureManager == null) return;
        com.blockworld.core.WorldCreature creature = creatureManager.nearest(cam.getLocation(), 3.2f);
        if (creature == null) {
            statusMessage = "Рядом нет существ. Подойди поближе и нажми F.";
        } else if (creature.type() == com.blockworld.core.CreatureType.VILLAGER) {
            statusMessage = "Житель: Добро пожаловать в нашу деревню! Загляни в дом.";
        } else if (creature.type() == com.blockworld.core.CreatureType.SLIME) {
            statusMessage = "Слайм подпрыгивает рядом. Он не нападает.";
        } else {
            statusMessage = creature.type().displayName() + " рядом. Существо спокойно гуляет по траве.";
        }
        updateHud();
    }

    private void toggleInventory() {
        if (!version.survival() || !worldReady) return;
        inventoryOpen = !inventoryOpen;
        craftingOpen = false;
        showInventoryOverlay(inventoryOpen);
        statusMessage = inventoryOpen ? "Инвентарь открыт. I — закрыть, C — открыть крафт." : "Инвентарь закрыт.";
        updateHud();
    }

    private void toggleCrafting() {
        if (!version.survival() || !worldReady) return;
        craftingOpen = !craftingOpen;
        inventoryOpen = false;
        showInventoryOverlay(craftingOpen);
        statusMessage = craftingOpen ? "Крафт открыт. Нажми 1–4 для создания рецепта, C — закрыть." : "Крафт закрыт.";
        updateHud();
    }

    private void showInventoryOverlay(boolean show) {
        if (inventoryPanel == null || inventoryText == null) return;
        if (show) {
            updateInventoryUi();
            if (inventoryPanel.getParent() == null) guiNode.attachChild(inventoryPanel);
            if (inventoryText.getParent() == null) guiNode.attachChild(inventoryText);
        } else {
            guiNode.detachChild(inventoryPanel);
            guiNode.detachChild(inventoryText);
        }
    }

    private void updateInventoryUi() {
        if (inventoryText == null) return;
        StringBuilder text = new StringBuilder();
        if (craftingOpen) {
            text.append("BLOCKWORLD 3D — МАСТЕРСКАЯ\n\n");
            text.append("Нажми номер рецепта (1–4), чтобы создать предмет:\n\n");
            for (CraftingRecipe recipe : craftingRecipes) {
                text.append(recipe.number()).append(". ").append(recipe.name()).append(" → ")
                        .append(recipe.result().displayName()).append(" × ").append(recipe.resultCount()).append("\n   Нужно: ")
                        .append(recipe.ingredientsText()).append(recipe.canCraft(inventory, craftedItems) ? "  [ГОТОВО]" : "  [НЕ ХВАТАЕТ]").append("\n");
            }
            text.append("\nC — закрыть мастерскую");
        } else {
            text.append("BLOCKWORLD 3D — ИНВЕНТАРЬ\n\nБлоки:\n");
            for (BlockType block : BlockType.values()) {
                int count = inventory.getOrDefault(block, 0);
                if (count > 0) text.append("• ").append(block.displayName()).append(" × ").append(count).append("\n");
            }
            text.append("\nПредметы:\n");
            for (ItemType item : ItemType.values()) {
                text.append("• ").append(item.displayName()).append(" × ").append(craftedItems.getOrDefault(item, 0)).append("\n");
            }
            text.append("\nI — закрыть инвентарь    C — мастерская");
        }
        inventoryText.setText(text.toString());
    }

    private void craftRecipe(int index) {
        if (!craftingOpen || index < 0 || index >= craftingRecipes.size()) return;
        CraftingRecipe recipe = craftingRecipes.get(index);
        if (recipe.craft(inventory, craftedItems)) {
            statusMessage = "Создано: " + recipe.result().displayName() + " × " + recipe.resultCount() + ".";
            try { PlayerDataStore.save(saveFile, inventory, craftedItems); }
            catch (IOException ex) { GameLog.error("Не удалось сохранить инвентарь после крафта", ex); }
        } else {
            statusMessage = "Не хватает ингредиентов для рецепта «" + recipe.name() + "».";
        }
        updateInventoryUi();
        updateHud();
    }

    private void eatFood() {
        if (!version.survival()) return;
        if (foodCount <= 0) {
            statusMessage = "Еды нет. Пока в стартовом наборе было 3 ягоды.";
        } else if (hunger >= 20f) {
            statusMessage = "Голод уже восстановлен.";
        } else {
            foodCount--;
            hunger = Math.min(20f, hunger + 6f);
            statusMessage = "Ты съел ягоды. Еды осталось: " + foodCount + ".";
        }
        updateHud();
    }

    private void selectSlot(int index) {
        if (index < 0 || index >= hotbar.size()) return;
        selectedBlock = hotbar.get(index);
        statusMessage = "Выбран блок: " + selectedBlock.displayName() + ".";
        updateHud();
    }

    private void saveWorld() {
        if (!worldReady) {
            statusMessage = "Подожди завершения загрузки мира.";
            updateHud();
            return;
        }
        try {
            if (modLoader != null) modLoader.beforeSave();
            world.save(saveFile, version);
            if (version.survival()) PlayerDataStore.save(saveFile, inventory, craftedItems);
            statusMessage = "Мир и инвентарь сохранены!";
        } catch (IOException ex) {
            statusMessage = "Ошибка сохранения: " + ex.getMessage();
            GameLog.error("Ошибка сохранения мира " + saveFile, ex);
        }
        updateHud();
    }

    private void updateHud() {
        if (hud == null || world == null || hotbar == null) return;
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < hotbar.size(); i++) {
            BlockType block = hotbar.get(i);
            bar.append(i + 1).append(':').append(block.displayName());
            if (version.survival()) bar.append(" x").append(inventory.getOrDefault(block, 0));
            if (block == selectedBlock) bar.append(" [выбран]");
            if (i < hotbar.size() - 1) bar.append("    ");
        }
        String controls = version.survival()
                ? "WASD — ходьба    Мышь — обзор    ПРОБЕЛ — прыжок    E — еда    I — инвентарь    C — крафт    F — общение    ESC — пауза"
                : "WASD — движение    Мышь — обзор    F — общение/контакт    ESC — пауза";
        String needs = version.survival()
                ? "Здоровье: " + (int) health + "/20    Голод: " + (int) hunger + "/20    Еда: " + foodCount
                    + "    Доски: " + craftedItems.getOrDefault(ItemType.PLANKS, 0)
                    + "    Палки: " + craftedItems.getOrDefault(ItemType.STICKS, 0)
                : "Творческий режим";
        String nature = version.id().compareTo("0.6.0") >= 0
                ? String.format(java.util.Locale.ROOT, "Время: %s    Погода: %s    R — сменить погоду",
                    dayClock < 0.25f ? "утро" : dayClock < 0.50f ? "день" : dayClock < 0.75f ? "вечер" : "ночь", raining ? "дождь" : "ясно")
                : "";
        String loading = worldReady ? "Мир загружен" : (worldDataReady ? loadingMessage : "Фоновая генерация/загрузка мира...");
        String performance = String.format(java.util.Locale.ROOT,
                "FPS: %.0f    Меши чанков: %d    Чанки данных: %d    Очередь: %d    Дальность: %d    Блоки: %,d",
                fpsEstimate, world.getRenderedChunkCount(), world.getChunkCount(),
                world.getPendingChunkCount(), world.getRenderDistanceChunks(), world.getBlockCount());
        String spawn = String.format(java.util.Locale.ROOT, "Spawn: X %.0f / Y %.0f / Z %.0f",
                spawnPosition.x, spawnPosition.y, spawnPosition.z);
        hud.setText("BLOCKWORLD 3D  |  " + version.id() + " " + version.displayName()
                + "\n" + controls + "    F6 — сохранить    F7 — дальность    F8 — режим граней    F10 — выход из паузы"
                + "\n" + needs
                + (nature.isEmpty() ? "" : "\n" + nature)
                + "\n" + performance + "    Моды: " + loadedModCount
                + "    Существа: " + world.getCreatureCount()
                + "\n" + spawn + "    Seed: " + world.getSeed() + "    Блок: " + selectedBlock.displayName()
                + "\n" + bar
                + "\n" + "Грани: " + (twoSidedRendering ? "двусторонние" : "оптимизированные")
                + "\n" + loading
                + "\n" + statusMessage);
        if (inventoryOpen || craftingOpen) updateInventoryUi();
    }

    @Override
    public void reshape(int width, int height) {
        super.reshape(width, height);
        if (hud != null && guiNode != null) {
            hud.setLocalTranslation(15f, height - 14f, 0f);
            if (hudPanel != null) hudPanel.setLocalTranslation(7f, height - 181f, 1f);
            if (crosshair != null) crosshair.setLocalTranslation(width / 2f - 5f, height / 2f + 7f, 0f);
            if (pausePanel != null) pausePanel.setLocalTranslation(width / 2f - 260f, height / 2f - 125f, 4f);
            if (pauseText != null) pauseText.setLocalTranslation(width / 2f - 205f, height / 2f + 82f, 5f);
            if (inventoryPanel != null) inventoryPanel.setLocalTranslation(width / 2f - 285f, height / 2f - 195f, 8f);
            if (inventoryText != null) inventoryText.setLocalTranslation(width / 2f - 260f, height / 2f + 165f, 9f);
        }
    }

    @Override
    public void handleError(String errorMsg, Throwable error) {
        GameLog.error("Ошибка jMonkeyEngine в потоке " + Thread.currentThread().getName() + ": "
                + (errorMsg == null ? "без описания" : errorMsg), error);
        super.handleError(errorMsg, error);
        String details = error == null ? String.valueOf(errorMsg)
                : error.getClass().getSimpleName() + ": " + error.getMessage();
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null,
                "jMonkeyEngine сообщил об ошибке. Полный стек сохранён в .logs\\latest-run.log.\n\n"
                        + details,
                "BLOCKWORLD 3D — ошибка графического движка", JOptionPane.ERROR_MESSAGE));
    }

    @Override
    public void destroy() {
        GameLog.info("Начато закрытие игрового приложения; worldReady=" + worldReady
                + "; thread=" + Thread.currentThread().getName());
        try {
            if (modLoader != null && worldReady) modLoader.beforeSave();
            if (world != null && worldReady) {
                try {
                    world.save(saveFile, version);
                    if (version.survival()) PlayerDataStore.save(saveFile, inventory, craftedItems);
                    GameLog.info("Мир и инвентарь автоматически сохранены при закрытии: " + saveFile.toAbsolutePath());
                } catch (Throwable error) {
                    GameLog.error("Не удалось сохранить мир при закрытии", error);
                }
            }
        } finally {
            try {
                if (modLoader != null) modLoader.close();
                super.destroy();
            } finally {
                if (!exitNotified && onGameExit != null) {
                    exitNotified = true;
                    onGameExit.run();
                    GameLog.info("Колбэк возврата в лаунчер выполнен.");
                }
            }
        }
    }
}
