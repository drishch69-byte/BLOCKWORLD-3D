package com.blockworld.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class PlayerDataStoreTest {
    @TempDir Path temp;

    @Test
    void savesAndLoadsBlockAndCraftedItemInventoryWithoutChangingWorldFile() throws Exception {
        Path world = temp.resolve("test.bwworld");
        Map<BlockType, Integer> blocks = new EnumMap<>(BlockType.class);
        Map<ItemType, Integer> items = new EnumMap<>(ItemType.class);
        blocks.put(BlockType.WOOD, 7);
        items.put(ItemType.PLANKS, 12);
        PlayerDataStore.save(world, blocks, items);

        Map<BlockType, Integer> loadedBlocks = new EnumMap<>(BlockType.class);
        Map<ItemType, Integer> loadedItems = new EnumMap<>(ItemType.class);
        PlayerDataStore.load(world, loadedBlocks, loadedItems);
        assertEquals(7, loadedBlocks.get(BlockType.WOOD));
        assertEquals(12, loadedItems.get(ItemType.PLANKS));
        assertTrue(java.nio.file.Files.exists(PlayerDataStore.sidecar(world)));
        assertFalse(java.nio.file.Files.exists(world));
    }
}
