package com.blockworld.core;

import org.junit.jupiter.api.Test;
import java.util.EnumMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class CraftingRecipeTest {
    @Test
    void planksRecipeConsumesWoodAndProducesFourPlanks() {
        Map<BlockType, Integer> blocks = new EnumMap<>(BlockType.class);
        Map<ItemType, Integer> items = new EnumMap<>(ItemType.class);
        blocks.put(BlockType.WOOD, 2);
        assertTrue(CraftingRecipe.starterRecipes().get(0).craft(blocks, items));
        assertEquals(0, blocks.get(BlockType.WOOD));
        assertEquals(4, items.get(ItemType.PLANKS));
    }

    @Test
    void recipeDoesNotConsumeAnythingWhenIngredientsAreMissing() {
        Map<BlockType, Integer> blocks = new EnumMap<>(BlockType.class);
        Map<ItemType, Integer> items = new EnumMap<>(ItemType.class);
        blocks.put(BlockType.WOOD, 1);
        assertFalse(CraftingRecipe.starterRecipes().get(0).craft(blocks, items));
        assertEquals(1, blocks.get(BlockType.WOOD));
        assertTrue(items.isEmpty());
    }

    @Test
    void recipeChainCreatesSticksWorkbenchAndTorches() {
        Map<BlockType, Integer> blocks = new EnumMap<>(BlockType.class);
        Map<ItemType, Integer> items = new EnumMap<>(ItemType.class);
        blocks.put(BlockType.WOOD, 4);
        blocks.put(BlockType.COAL_ORE, 1);
        var recipes = CraftingRecipe.starterRecipes();
        assertTrue(recipes.get(0).craft(blocks, items));
        assertTrue(recipes.get(0).craft(blocks, items));
        assertTrue(recipes.get(1).craft(blocks, items));
        assertTrue(recipes.get(2).craft(blocks, items));
        assertTrue(recipes.get(3).craft(blocks, items));
        assertEquals(2, items.get(ItemType.STICKS));
        assertEquals(1, items.get(ItemType.CRAFTING_TABLE));
        assertEquals(4, items.get(ItemType.TORCH));
    }
}
